#!/usr/bin/env
from brain_games.games.progression_logic import main


if __name__ == "__main__":
    main()
