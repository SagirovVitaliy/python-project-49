#!/usr/bin/env
from brain_games.games.prime_logic import main


if __name__ == "__main__":
    main()
