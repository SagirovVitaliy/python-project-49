#!/usr/bin/env
from brain_games.games.even_logic import main


if __name__ == "__main__":
    main()
