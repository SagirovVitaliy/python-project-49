#!/usr/bin/env
from brain_games.games.calc_logic import main


if __name__ == "__main__":
    main()
