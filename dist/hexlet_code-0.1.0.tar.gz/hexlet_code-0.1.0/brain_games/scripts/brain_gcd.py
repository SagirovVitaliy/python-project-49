#!/usr/bin/env
from brain_games.games.gcd_logic import main


if __name__ == "__main__":
    main()
