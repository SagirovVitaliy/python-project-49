### Hexlet tests and linter status:
[![Actions Status](https://github.com/SagirovVitaliy/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/SagirovVitaliy/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/098e286bb2d578195912/maintainability)](https://codeclimate.com/github/SagirovVitaliy/python-project-49/maintainability)

Пример установки и игра в brain-even
https://asciinema.org/a/hBzz5SNzPYuauZMLTO65zJDG3

Игра brain-calc
https://asciinema.org/a/5ENPhad8zOpikeM80HMdXjYNc

Игра brain-gcd
https://asciinema.org/a/au492bxcWQ8uNnRAgw2oQmkGX

Игра brain-progression
https://asciinema.org/a/8PzoGeW2zsooyZhv8WV4OQ0xP

Игра brain-prime
https://asciinema.org/a/RCtfjT3jN4rIsaloatdursazh


