### Hexlet tests and linter status:
Пример установки и игра в brain-even
https://asciinema.org/a/hBzz5SNzPYuauZMLTO65zJDG3

Игра brain-calc
https://asciinema.org/a/5ENPhad8zOpikeM80HMdXjYNc

Игра brain-gcd
 https://asciinema.org/a/au492bxcWQ8uNnRAgw2oQmkGX

[![Actions Status](https://github.com/SagirovVitaliy/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/SagirovVitaliy/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/098e286bb2d578195912/maintainability)](https://codeclimate.com/github/SagirovVitaliy/python-project-49/maintainability)

[![Test Coverage](https://api.codeclimate.com/v1/badges/098e286bb2d578195912/test_coverage)](https://codeclimate.com/github/SagirovVitaliy/python-project-49/test_coverage)